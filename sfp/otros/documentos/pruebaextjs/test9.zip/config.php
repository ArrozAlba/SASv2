<?
	//Configuración del acceso a base de datos

	$config['config']['bda']['server']				='localhost';
	$config['config']['bda']['type']				='mysql';
	$config['config']['bda']['bda']					='demo';
	$config['config']['bda']['user']				='root';
	$config['config']['bda']['password']			='';
/*


	$config['config']['bda']['server']				='localhost';
	$config['config']['bda']['type']				='mysql';
	$config['config']['bda']['bda']					='limestu_demo';
	$config['config']['bda']['user']				='limestu_demo';
	$config['config']['bda']['password']			='demo001';

*/
	$config['config']['cookies']['time']			=86400;

	$config['config']['session']['name']			='extjsdemo';

	$config['config']['date']['format']				='d/m/Y';
	$config['config']['date']['format_ext']			='d/m/Y H:i:s';

	$config['config']['charset']					='UTF-8';

	$config['config']['miscelanea']['theme_default']='default';

	$config['config']['mail']['to_name']			='Manolo López Torrent';
	$config['config']['mail']['to_mail']			='manolo.lopez@limestudio.es';
	$config['config']['mail']['smtp']['server']		='localhost';
	$config['config']['mail']['smtp']['user']		='';
	$config['config']['mail']['smtp']['password']	='';

	$config['config']['url']['path']				='/test/test9/'; //Barra final obligatorio
	$config['config']['url']['protocol']			='http';





?>